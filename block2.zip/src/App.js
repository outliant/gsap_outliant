import { useRef, useLayoutEffect } from "react";
import { gsap } from "gsap";
import { ReactComponent as Block2 } from "./img/Block2v4.svg";
import "./styles.css";

export default function App() {
  useLayoutEffect(() => {
    // Here goes the magic!
    gsap.to("#blockleft", {
      duration: 2,
      y: 30,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });
    gsap.to("#blockright", {
      duration: 2,
      y: 0,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });

    gsap.to("#blinking", {
      duration: 0.3,
      opacity: 0,
      repeat: -1,
      repeatDelay: 0.1,
      yoyo: true,
      ease: "sine.inOut"
    });

    gsap.to("#circleup", {
      duration: 1,
      y: 70,
      repeat: -1,
      repeatDelay: 1,
      delay: 1,
      yoyo: true,
      ease: "sine.inOut"
    });
    gsap.to("#circledown", {
      duration: 1,
      y: 130,
      repeat: -1,
      repeatDelay: 1,
      delay: 1,
      yoyo: true,
      ease: "sine.inOut"
    });

    gsap.to("#radiobutton", {
      duration: 0.5,
      x: 27,
      fill: "#DFF857",
      repeat: -1,
      repeatDelay: 1,
      yoyo: true,
      ease: "sine.inOut"
    });

    gsap.to("#box", {
      duration: 0.5,
      stroke: "#DFF857",
      repeat: -1,
      repeatDelay: 1,
      yoyo: true,
      ease: "sine.inOut"
    });
  }, []);

  return (
    <div className="App">
      <h1>GSAP Animation for Block2</h1>
      <div>
        <Block2 />
      </div>
    </div>
  );
}
