import { useLayoutEffect } from "react";
import { gsap } from "gsap-trial";
import { MorphSVGPlugin } from "gsap-trial/MorphSVGPlugin";
import { DrawSVGPlugin } from "gsap-trial/DrawSVGPlugin";
import { ReactComponent as Loader } from "./img/LoaderPluginv6.svg";

import "./styles.css";

gsap.registerPlugin(DrawSVGPlugin);
gsap.registerPlugin(MorphSVGPlugin);

export default function App() {
  useLayoutEffect(() => {
    // Here goes the magic!
    MorphSVGPlugin.convertToPath("#circle3");
    MorphSVGPlugin.convertToPath("#circle1black");
    MorphSVGPlugin.convertToPath("#circle3black");

    gsap.set("#circle2", { rotation: -90, transformOrigin: "center center" });
    gsap.set("#circle1black", {
      rotation: -90,
      transformOrigin: "center center"
    });
    gsap.set("#circle3black", {
      rotation: -90,
      transformOrigin: "center center"
    });

    var tl = gsap.timeline({ repeat: -1 });
    tl.to("#circle1", { alpha: 1, duration: 0 })
      .to("#circle2", { alpha: 0, duration: 0 })
      .to("#circle3", { alpha: 1, duration: 0 })
      .to("#circle1black", { alpha: 0, duration: 0 })
      .to("#circle3black", { alpha: 0, duration: 0 })
      .to("#Loader", {
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#center", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#blackpoint", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })

      .to("#Loader", {
        scale: 1,
        transformOrigin: "center center",
        duration: 1,
        force3D: false
      })
      .to("#circle2", { alpha: 1, duration: 0 })
      .to("#circle2", { drawSVG: "100% 100%", duration: 1 })
      .to("#circle1black", { alpha: 1, duration: 0, delay: -1 })
      .to("#circle1black", { drawSVG: "100% 100%", duration: 1, delay: -1 })
      .to("#circle3black", { alpha: 1, duration: 0, delay: -1 })
      .to("#circle3black", { drawSVG: "100% 100%", duration: 1, delay: -1 })
      .to("#center", {
        alpha: 1,
        scale: 1,
        transformOrigin: "center center",
        duration: 1,
        delay: -1
      })
      .to("#blackpoint", {
        scale: 1,
        transformOrigin: "center center",
        alpha: 1,
        duration: 0.5,
        delay: -1
      })
      .to("#blackpoint", {
        x: 25,
        y: -10,
        scale: 0,
        transformOrigin: "center center",
        duration: 0.5
      })
      //Here Logo issue
      .to("#outliant_maskup", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5
      }) //0.5
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5,
        delay: -0.1
      })
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", { alpha: 0, duration: 0 })
      //.to("#uplogo", { alpha: 0, duration: 0 })
      //.to("#uplogo", { drawSVG: "0%", duration: 1 })
      //.to("#downlogo", { drawSVG: "0% 0%", duration: 1 })
      //.to("#uplogo", { alpha: 1, duration: 0 })
      /* .to("#uplogo", { alpha:1, drawSVG: "0% 100%", duration: 1 })
      .to("#OutliantLogo", { alpha: 0, duration: 0, delay: 100 });
      */

      //Second
      .to("#Loader", {
        scale: 0,
        transformOrigin: "center center",
        duration: 0.25,
        force3D: false
      })
      /*
      .to("#circle1", { alpha: 1, duration: 0 })
      .to("#circle2", { alpha: 0, duration: 0 })
      .to("#circle3", { alpha: 1, duration: 0 })
      .to("#circle1black", { alpha: 0, duration: 0 })
      .to("#circle3black", { alpha: 0, duration: 0 })
      .to("#circle2", { rotation: -90, transformOrigin: "center center", duration: 0 })
      .to("#circle1black", { rotation: -90, transformOrigin: "center center", duration: 0 })
      .to("#circle3black", { rotation: -90, transformOrigin: "center center", duration: 0 })
      .to("#center", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#blackpoint", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#Loader", {
        scale: 1,
        transformOrigin: "center center",
        duration: 0.5,
        force3D: false
      })
      //Second circles
      .to("#circle2", { alpha: 1, duration: 0 })
      .to("#circle2", { drawSVG: "100% 100%", duration: 1 })
      .to("#circle1black", { alpha: 1, duration: 0, delay: -1 })
      .to("#circle1black", { drawSVG: "100% 100%", duration: 1, delay: -1 })
      .to("#circle3black", { alpha: 1, duration: 0, delay: -1 })
      .to("#circle3black", { drawSVG: "100% 100%", duration: 1, delay: -1 })
      .to("#center", {
        alpha: 1,
        scale: 1,
        transformOrigin: "center center",
        duration: 1,
        delay: -1
      })
      .to("#blackpoint", {
        scale: 1,
        transformOrigin: "center center",
        alpha: 1,
        duration: 0.5,
        delay: -1
      })
      .to("#blackpoint", {
        x: 25,
        y: -10,
        scale: 0,
        transformOrigin: "center center",
        duration: 0.5
      })*/
      .to("#OutliantLogo", { alpha: 0, duration: 0, delay: 1 });
  }, []);

  return (
    <div className="App">
      <h1>GSAP Loader with Plugin</h1>
      <div>
        <Loader />
      </div>
    </div>
  );
}
