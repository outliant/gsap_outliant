import {useRef, useLayoutEffect} from "react"
import {gsap} from "gsap"
import {ReactComponent as Block1} from "./img/Block1v5.svg"
import "./styles.css"

export default function App() {
  useLayoutEffect(() => {
    // Create a timeline
    let tl = gsap.timeline({repeat: -1})
    tl.to("#window", {y: 30, ease: "sine", duration: 2}).to("#window", {
      y: 0,
      ease: "sine",
      duration: 2
    })

    let tl2 = gsap.timeline({repeat: -1})
    tl2
      .to("#cubeleft", {y: 260, x: -5, ease: "sine", duration: 2})
      .to("#cubeleft", {y: 226, x: 0, ease: "sine", duration: 2})

    let tl3 = gsap.timeline({repeat: -1})
    tl3
      .to("#cuberight", {y: 420, ease: "sine", duration: 2})
      .to("#stats", {
        rotation: 360,
        transformOrigin: "center center",
        repeat: 0,
        ease: "Linear.easeNone"
      })
      .to("#cuberight", {y: 366.8, ease: "sine", duration: 2})

    //Right now descending into hell
    //let tl4 = gsap.timeline({repeat: -1});

    gsap.set("#part1", {transformOrigin: "bottom left", rotation: -15})
    gsap.to("#part1", {
      duration: 1,
      rotation: 20,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })

    gsap.set("#part2", {
      transformOrigin: "bottom left",
      x: 10,
      rotation: -15
    })
    gsap.to("#part2", {
      duration: 1,
      rotation: 0,
      x: 20,
      y: 58,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })

    gsap.set("#part3", {
      transformOrigin: "bottom left",
      x: 35,
      y: 8,
      rotation: -15
    })
    gsap.to("#part3", {
      duration: 1,
      rotation: 20,
      x: 48,
      y: 23,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })

    gsap.set("#part4", {
      transformOrigin: "bottom left",
      x: 38,
      y: -8,
      rotation: -15
    })
    gsap.to("#part4", {
      duration: 1,
      rotation: 20,
      x: 68,
      y: 15,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })

    gsap.set("#arrowend", {
      transformOrigin: "bottom left",
      x: 57,
      y: -10,
      rotation: -15
    })
    gsap.to("#arrowend", {
      duration: 1,
      rotation: 15,
      x: 90,
      y: 25,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })
    gsap.to("#arrowend", {duration: 0, opacity: 1, delay: 2})
  }, [])

  return (
    <div className="App">
      <h1>GSAP Animation for Block1</h1>
      <div>
        <Block1 />
      </div>
    </div>
  )
}
