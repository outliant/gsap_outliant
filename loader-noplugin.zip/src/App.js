import { useRef, useLayoutEffect } from "react";
import { gsap } from "gsap";
import { ReactComponent as Loader } from "./img/Loader_v9.svg";
import "./styles.css";

export default function App() {
  useLayoutEffect(() => {
    // Here goes the magic!
    var tl = gsap.timeline({ repeat: -1 });
    tl.to("#Loader", {
      scale: 0,
      transformOrigin: "center center",
      duration: 0
    })
      .to("#triangle", { alpha: 0, duration: 0 })
      .to("#blackshape", { alpha: 0, duration: 0 })
      .to("#circle2", { alpha: 0, duration: 0 })
      .to("#center", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#blackpoint", {
        alpha: 0,
        scale: 0,
        transformOrigin: "center center",
        duration: 0
      })
      .to("#OutliantLogo", { alpha: 0, duration: 0 })
      .to("#Loader", {
        scale: 1,
        transformOrigin: "center center",
        duration: 1,
        force3D: false
      })
      .to("#center", {
        alpha: 1,
        scale: 1,
        transformOrigin: "center center",
        duration: 0.5
      })
      //here circle movement
      .to("#triangle", { alpha: 1, duration: 0.3 })
      .to("#circle2", { alpha: 1, duration: 0.3, delay: -0.6 })
      .to("#triangle", {
        rotation: 360,
        transformOrigin: "center bottom",
        duration: 2,
        delay: -0.1
      })
      .to("#blackshape", { alpha: 1, duration: 0.3, delay: 0 })
      .to("#blackshape", {
        rotation: 360,
        transformOrigin: "center bottom",
        duration: 2,
        delay: -2
      })
      .to("#circle2", { alpha: 1, duration: 0.5, delay: -0.5 })
      .to("#circle1", { alpha: 0, duration: 0.5 })
      .to("#circle2", { alpha: 1, duration: 0.5, delay: -0.5 })
      .to("#circle3", { alpha: 0, duration: 0.5, delay: -1 })
      .to("#blackpoint", {
        scale: 1,
        transformOrigin: "center center",
        alpha: 1,
        duration: 0.5
      })
      .to("#blackpoint", {
        x: 25,
        y: -10,
        scale: 0,
        transformOrigin: "center center",
        duration: 0.5
      })
      //Masking Outliant logo
      .to("#OutliantLogo", { alpha: 1, duration: 0, delay: 0 })
      .to("#outliant_maskup", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5
      }) //0.5
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5,
        delay: -0.1
      })
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", { alpha: 0, duration: 0 })
      .to("#Loader", {
        scale: 0,
        alpha: 0,
        transformOrigin: "center center",
        duration: 0.3,
        delay: 1
      })
      .to("#OutliantLogo", { alpha: 0, scale: 0, duration: 0 })
      .to("#circle1", { alpha: 1, duration: 0 })
      .to("#circle2", { alpha: 0, duration: 0 })
      .to("#circle3", { alpha: 1, duration: 0 })
      .to("#Loader", {
        scale: 1,
        alpha: 1,
        transformOrigin: "center center",
        force3D: false,
        duration: 1
      })
      .to("#triangle", { alpha: 0, rotation: 0, duration: 0 })
      .to("#blackshape", { alpha: 0, rotation: 0, duration: 0 })
      //here circle movement 2 !!!
      .to("#triangle", { alpha: 1, duration: 0.3 })
      .to("#circle2", { alpha: 1, duration: 0.3, delay: -0.6 })
      .to("#triangle", {
        rotation: 360,
        transformOrigin: "center bottom",
        duration: 2,
        delay: -0.1
      })
      .to("#blackshape", { alpha: 1, duration: 0.3, delay: 0 })
      .to("#blackshape", {
        rotation: 360,
        transformOrigin: "center bottom",
        duration: 2,
        delay: -2
      })
      .to("#circle2", { alpha: 1, duration: 0.5, delay: -0.5 })
      .to("#circle1", { alpha: 0, duration: 0.5 })
      .to("#circle2", { alpha: 1, duration: 0.5, delay: -0.5 })
      .to("#circle3", { alpha: 0, duration: 0.5, delay: -1 })
      .to("#blackpoint", {
        x: 0,
        y: 0,
        scale: 0,
        transformOrigin: "center center",
        alpha: 0,
        duration: 0
      })
      .to("#blackpoint", {
        scale: 1,
        transformOrigin: "center center",
        alpha: 1,
        duration: 0.5
      })
      .to("#blackpoint", {
        x: 25,
        y: -10,
        scale: 0,
        transformOrigin: "center center",
        duration: 0.5
      })
      //Masking Outliant logo 2
      .to("#OutliantLogo", { alpha: 1, scale: 1, duration: 0, delay: 0 })
      .to("#outliant_maskup", {
        alpha: 1,
        rotation: 0,
        transformOrigin: "center bottom",
        duration: 0
      })
      .to("#outliant_maskdown", {
        alpha: 1,
        rotation: 0,
        transformOrigin: "center bottom",
        duration: 0
      })
      .to("#outliant_maskup", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5,
        delay: 0.5
      })
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", {
        rotation: -180,
        transformOrigin: "center bottom",
        duration: 0.5,
        delay: -0.1
      })
      .to("#outliant_maskup", { alpha: 0, duration: 0 })
      .to("#outliant_maskdown", { alpha: 0, duration: 0 })
      .to("#Loader", {
        scale: 0,
        alpha: 0,
        transformOrigin: "center center",
        duration: 0.3,
        delay: 1
      });
  }, []);

  return (
    <div className="App">
      <h1>GSAP Loader without Plugin</h1>
      <div>
        <Loader />
      </div>
    </div>
  );
}
